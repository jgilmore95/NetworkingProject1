//package clientside;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;


public class ClientSide {
    
    private static int threadCount;
    private static ClientThread[] threads;
    private static String myHost;

    public static void main(String[] args) {
        UserInterface ui;
        String command;
        boolean running = true;
        
        if (args.length < 1) { //ends if no command line arg.
            System.out.println("Error: Invalid Hostnamne (try localhost)");
            return;
        }    
        else {
            myHost = args[0];
            if (args.length == 2) { //optional command ln arg for thread count
                threadCount = Integer.parseInt(args[1]);
            }
            else {
                System.out.println("Default thread count: 1");
                threadCount = 1;
            }
        }
        if (threadCount < 1) {
            threadCount = 1;
        }
        
        ui = new UserInterface(threadCount);
        while (running) {
            ui.displayMenu();
            command = ui.getCommand();

            if (command.equals("thread")) {
                threadCount = ui.changeThreadCount();
            }
            else if (command.equals("exit")) {
                signalServerExit();
                System.out.printf("Ending program%n");
                running = false;
            }
            else {
                System.out.printf("Command is: %s%n", command);
                System.out.println("From Server: ");
                generateThreads(threadCount, command, myHost);
                runThreads();
                getResults(threadCount);
            }
        }
        
        return;
    }
    
// Makes the threads
    private static void generateThreads(int threadCount, String command, String myHost) {
        threads = new ClientThread[threadCount];
        
        for (int i = 0; i < threadCount; i++) {
            threads[i] = new ClientThread(command, myHost);
        }
    }

    private static void getResults(int threadCount) {
        double sum = 0;
        
        System.out.printf("Server response times (milliseconds): %n");
        for(ClientThread t : threads) {
            System.out.printf("%.2f, ", t.getTotalTime());
	    sum += t.getTotalTime();
        }
        System.out.printf("%nLatency (mean server response time): %.2f ms", (sum/((double)threadCount)));
        System.out.printf("%n");
    }

    private static void runThreads() {
        int i;
        boolean running = true;
        for (i = 0; i < threads.length; i++) {
            threads[i].start();
        }
        while (running) {
            running = false;
            for (i = 0; i < threads.length; i++) {
                if (threads[i].isAlive()) {
                    running = true;
                }
            }
        }
    }
    
    private static void signalServerExit() {
        
        try {
            // What happens when the server ends
            Socket socket = new Socket(myHost, ClientThread.portNumber);
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            output.printf("exit%n");
            socket.close();
        }
        catch (IOException ex) {}
    }
}
